# Kallix Product-Level Brand Kit

Recommended path: `/public/assets/kallix/`

Includes logos, favicons, agent states, animated states, UI icons, React components, CSS, and web manifest.
