const statusMap = {
  healthy: "/assets/kallix/agent/png/Kallix-Agent-Healthy-256.png",
  warning: "/assets/kallix/agent/png/Kallix-Agent-Warning-256.png",
  compromised: "/assets/kallix/agent/animated/Kallix-Agent-Alert-Pulsing.gif",
  offline: "/assets/kallix/agent/png/Kallix-Agent-Offline-256.png",
  scanning: "/assets/kallix/agent/animated/Kallix-Agent-Scanning.gif",
  responding: "/assets/kallix/agent/animated/Kallix-Agent-Responding.gif",
};

export default function KallixAgent({ status = "healthy", size = 32 }) {
  return <img src={statusMap[status] || statusMap.healthy} alt={`Kallix agent ${status}`} width={size} height={size} className={`kallix-agent kallix-agent-${status}`} />;
}
