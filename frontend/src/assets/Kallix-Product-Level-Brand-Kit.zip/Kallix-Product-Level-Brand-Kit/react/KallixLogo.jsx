export default function KallixLogo({ horizontal = true, animated = false }) {
  const src = animated
    ? "/assets/kallix/animations/Kallix-Logo-Pulse.gif"
    : horizontal
      ? "/assets/kallix/logo/svg/Kallix-Logo-Horizontal.svg"
      : "/assets/kallix/logo/svg/Kallix-Logo-Full.svg";

  return <img src={src} alt="Kallix" className="kallix-logo" />;
}
